Galaxy Watch8 专用｜赔率保本计算器 v1.0
===================================

基于你上传的 HedgeFloating v3.3 源代码改造。
原版 HedgeMath 算法文件保留，Java 包名替换为 com.hthedge.watch8。

功能
- 两单默认模式：保险保本、两单收益均衡、手动保险金额。
- 三单模式：两份保险联动保本、三单收益均衡、手动保险金额。
- 实时显示主单/保险1/保险2/其他比分的净盈亏、最小保险金额与建议金额。
- 若两张保险赔率不满足联动保本条件，明确提示不可能，绝不假装可以保本。
- 输入金额、赔率保存在本机，重新打开默认还是两单，保持原版行为。
- 原生数字输入界面：0-9、小数点、退格、清空、完成；不使用系统输入法。
- AMOLED 纯黑底、圆屏滚动界面，适配 Galaxy Watch8 44mm 480x480。
- 完全离线，不需要网络、通知、悬浮权限、前台服务或任何运行时权限。
- 包名 com.hthedge.watch8；与手机悬浮版包名不同，可并存。

使用
1. 打开 APP：默认两单，输入主单金额、主单赔率和保险赔率。
2. 点绿色金额区域，打开自带数字键盘，点【完成 ✓】保存返回。
3. 顶部切换【两张单／三张单】；选择【保险保本／收益均衡】。
4. 想自行编辑保险金额，点该行数值输入；程序自动进入【手动保险金额模式】。
5. 向上滑动看各张单命中时净盈亏和未列出比分的最大损失。
6. 输入时按手表返回手势，也会保留刚输入的数字。

注意
- 只对所列“互斥比分”进行计算。若出现其他比分会损失全部本金。
- 不接入投注平台，不执行下注，不保证实际保本：可能有手续费、交易限制、赔率变化。
- 界面独立适配，功能逻辑沿用 v3.3；并非直接在手表显示原悬浮窗口。

GitHub Actions 一包上传编译（与之前项目一致）
1. 新建或打开 GitHub 仓库（建议 Watch8-HedgeOdds）。
2. 把 Watch8_HedgeOdds_v1_OneUpload.zip 上传到仓库根目录（不要解压）。
3. 将文件 build-apk_Watch8_HedgeOdds_v1.txt 的全文复制到 .github/workflows/build-apk.yml，保存 Commit。
4. Actions > Build Watch8 Hedge Odds APK > Run workflow。
5. 成功后打开本次构建，下载 Watch8-HedgeOdds-v1-APK，解压取得 app-debug.apk。
6. 用 Wear Installer 2 或 adb 安装到 Galaxy Watch8。

编译环境：Java 17 / Gradle 8.9 / AGP 8.7.3 / Android 35。
这份源码已验证 HedgeMath 回归测试；是否能成功打包 APK 以 GitHub Actions 结果为准。
