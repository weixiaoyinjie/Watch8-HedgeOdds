package com.hthedge.watch8;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * Round Wear OS odds calculator. All interaction stays inside this Activity.
 * No overlay permission, no background service and no system IME are required.
 * The unchanged v3.3 HedgeMath class is reused for both 2- and 3-bet settlement.
 */
public final class MainActivity extends Activity {
    private static final int BG = Color.BLACK;
    private static final int SURFACE = 0xff141d1e;
    private static final int BORDER = 0xff344849;
    private static final int LIGHT = 0xfff1f7f6;
    private static final int DIM = 0xffaabbb9;
    private static final int GREEN = 0xff4de0bc;
    private static final int BAD = 0xffff8588;
    private static final int WARN = 0xffffc477;
    private static final int ACTIVE = 0xff116957;
    private static final int BREAK_EVEN = 0;
    private static final int BALANCED = 1;
    private static final int MANUAL = 2;
    // Index matches the original v3.3 preference keys (if present on the same install).
    private static final String[] PREF = {
            "mainStake", "mainOdds", "coverOdds", "coverStake", "cover2Odds", "cover2Stake"
    };
    private static final String[] NAME = {
            "主单金额", "主单赔率", "保险1赔率", "保险1金额", "保险2赔率", "保险2金额"
    };
    private static final String[] DEFAULT = {"10000", "5.50", "5.50", "", "5.50", ""};
    private final String[] values = new String[6];
    private final DecimalFormat money = new DecimalFormat("#,##0.00", new DecimalFormatSymbols(new Locale("es", "AR")));
    private SharedPreferences prefs;
    private int mode = BREAK_EVEN;
    private int slips = 2;
    private int editing = -1;
    private String editBuffer = "";
    private boolean replaceFirstDigit = false;
    private ScrollView homeScroll;
    private TextView keypadValue;
    private int screenDp;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(BG);
        getWindow().setStatusBarColor(BG);
        // Prefer AMOLED black; never enable an app-level always-on mode.
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE);
        prefs = getSharedPreferences("calculator", MODE_PRIVATE);
        for (int i = 0; i < values.length; i++) values[i] = prefs.getString(PREF[i], DEFAULT[i]);
        mode = prefs.getInt("mode", BREAK_EVEN);
        if (mode < BREAK_EVEN || mode > MANUAL) mode = BREAK_EVEN;
        slips = 2; // Matches the original: always start with two slips.
        screenDp = (int) (getResources().getDisplayMetrics().widthPixels /
                getResources().getDisplayMetrics().density + 0.5f);
        showHome();
    }

    private void showHome() {
        editing = -1;
        Summary summary = compute();
        LinearLayout body = column();
        int padX = Math.min(45, Math.max(30, Math.round(screenDp * 0.125f)));
        body.setPadding(dp(padX), dp(19), dp(padX), dp(35));
        ScrollView screen = new ScrollView(this);
        screen.setBackgroundColor(BG);
        screen.setFillViewport(false);
        screen.setVerticalScrollBarEnabled(false);
        screen.addView(body, new ScrollView.LayoutParams(-1, -2));
        homeScroll = screen;
        setContentView(screen);

        TextView title = text("保本赔率计算", 18, LIGHT, true);
        title.setGravity(Gravity.CENTER);
        body.addView(title, lineParams(33, 0, 4));

        LinearLayout tickets = row();
        addCell(tickets, "两张单", slips == 2, () -> changeSlips(2));
        addCell(tickets, "三张单", slips == 3, () -> changeSlips(3));
        body.addView(tickets, lineParams(39, 0, 9));

        addInput(body, 0);
        addInput(body, 1);
        addInput(body, 2);
        if (slips == 3) addInput(body, 4);

        LinearLayout options = row();
        addCell(options, slips == 3 ? "双保险保本" : "保险保本", mode == BREAK_EVEN,
                () -> changeMode(BREAK_EVEN));
        addCell(options, "收益均衡", mode == BALANCED, () -> changeMode(BALANCED));
        body.addView(options, lineParams(39, 4, 8));
        if (mode == MANUAL) {
            TextView manual = text("手动保险金额模式", 11, WARN, false);
            manual.setGravity(Gravity.CENTER);
            body.addView(manual, lineParams(19, 0, 4));
        }

        addResultLine(body, summary.proposed, GREEN, true);
        addInput(body, 3);
        if (slips == 3) addInput(body, 5);
        addResultLine(body, summary.status, summary.statusColor, true);
        if (slips == 3) {
            addResultLine(body, summary.coverage, summary.coverageColor, false);
        }
        addResultLine(body, summary.minimum, DIM, false);
        addResultLine(body, summary.equal, DIM, false);

        TextView heading = text(slips == 3 ? "三种比分净盈亏" : "两种比分净盈亏", 13, LIGHT, true);
        heading.setGravity(Gravity.CENTER);
        body.addView(heading, lineParams(29, 9, 1));
        addProfit(body, "主单命中", summary.mainProfit);
        addProfit(body, slips == 3 ? "保险1命中" : "保险命中", summary.cover1Profit);
        if (slips == 3) addProfit(body, "保险2命中", summary.cover2Profit);
        addProfit(body, "其他比分", summary.otherProfit);

        TextView foot = text("仅计算所列互斥比分的账面盈亏\n其他比分可能损失全部投入", 10, DIM, false);
        foot.setGravity(Gravity.CENTER);
        body.addView(foot, lineParams(40, 7, 1));
        save();
    }

    private void addInput(LinearLayout parent, int i) {
        LinearLayout r = row();
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), 0, dp(9), 0);
        r.setBackground(round(SURFACE, 11, BORDER));
        String label = i == 2 && slips == 2 ? "保险赔率" :
                i == 3 && slips == 2 ? "保险金额" : NAME[i];
        TextView caption = text(label, 12, DIM, false);
        caption.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(caption, new LinearLayout.LayoutParams(0, -1, 1));
        String display = values[i].trim().isEmpty() ? "点击输入" : values[i];
        TextView number = text(display, 16, GREEN, true);
        number.setSingleLine(true);
        number.setEllipsize(TextUtils.TruncateAt.START);
        number.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        number.setMaxWidth(dp(Math.round(screenDp * 0.46f)));
        r.addView(number, new LinearLayout.LayoutParams(-2, -1));
        r.setContentDescription(label + "，" + display + "，点击编辑");
        r.setOnClickListener(v -> openKeypad(i));
        parent.addView(r, lineParams(45, 0, 5));
    }

    private void addProfit(LinearLayout parent, String label, double pnl) {
        TextView view;
        if (!Double.isFinite(pnl)) {
            view = text(label + "：—", 13, DIM, true);
        } else {
            view = text(label + "：" + (pnl > 0.004 ? "+" : "") + cash(pnl),
                    13, pnl >= -0.005 ? GREEN : BAD, true);
        }
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setPadding(dp(9), dp(5), dp(7), dp(5));
        view.setBackground(round(SURFACE, 9, BORDER));
        parent.addView(view, lineParams(40, 0, 4));
    }

    private void addResultLine(LinearLayout parent, String message, int color, boolean emphasize) {
        if (message == null || message.isEmpty()) return;
        TextView t = text(message, emphasize ? 13 : 12, color, emphasize);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(3), dp(4), dp(3), dp(4));
        parent.addView(t, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addCell(LinearLayout parent, String label, boolean selected, Runnable action) {
        TextView button = text(label, 12, selected ? LIGHT : DIM, true);
        button.setGravity(Gravity.CENTER);
        button.setBackground(round(selected ? ACTIVE : SURFACE, 11, selected ? GREEN : BORDER));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
        lp.setMargins(dp(2), 0, dp(2), 0);
        parent.addView(button, lp);
        button.setOnClickListener(v -> action.run());
    }

    private void changeSlips(int next) {
        if (next == slips) return;
        slips = next;
        // The original overlay resets to break-even after switching 2/3 slips.
        mode = BREAK_EVEN;
        showHome();
    }

    private void changeMode(int next) {
        mode = next;
        showHome();
    }

    private void openKeypad(int index) {
        editing = index;
        editBuffer = values[index];
        replaceFirstDigit = true;
        showKeypad();
    }

    private void showKeypad() {
        // One native full-screen keypad; avoids cramped Wear OS IME and supports decimals.
        ScrollView viewport = new ScrollView(this);
        viewport.setFillViewport(true);
        viewport.setVerticalScrollBarEnabled(false);
        viewport.setBackgroundColor(BG);
        LinearLayout wrapper = column();
        wrapper.setGravity(Gravity.CENTER);
        wrapper.setPadding(dp(12), dp(10), dp(12), dp(12));
        viewport.addView(wrapper, new ScrollView.LayoutParams(-1, -1));
        setContentView(viewport);

        TextView label = text(NAME[editing], 14, DIM, true);
        label.setGravity(Gravity.CENTER);
        wrapper.addView(label, lineParams(27, 0, 0));

        keypadValue = text(editBuffer.isEmpty() ? "0" : editBuffer, 30, GREEN, true);
        keypadValue.setGravity(Gravity.CENTER);
        keypadValue.setSingleLine(true);
        keypadValue.setAutoSizeTextTypeUniformWithConfiguration(14, 30, 1, TypedValue.COMPLEX_UNIT_SP);
        wrapper.addView(keypadValue, lineParams(42, 0, 8));

        LinearLayout keypad = column();
        int width = Math.min(235, screenDp - 78);
        wrapper.addView(keypad, new LinearLayout.LayoutParams(dp(width), -2));
        String[][] keys = {{"7", "8", "9"}, {"4", "5", "6"}, {"1", "2", "3"}, {".", "0", "⌫"}};
        for (String[] keyRow : keys) {
            LinearLayout r = row();
            for (String key : keyRow) addKey(r, key, false, () -> inputKey(key));
            keypad.addView(r, lineParams(45, 0, 5));
        }
        LinearLayout commands = row();
        addKey(commands, "清空", false, () -> {
            editBuffer = "";
            replaceFirstDigit = false;
            updateKeypad();
        });
        addKey(commands, "完成 ✓", true, this::commitEditing);
        keypad.addView(commands, lineParams(44, 0, 0));
    }

    private void addKey(LinearLayout r, String label, boolean primary, Runnable action) {
        TextView key = text(label, (label.length() > 2) ? 15 : 23, primary ? Color.BLACK : LIGHT, true);
        key.setGravity(Gravity.CENTER);
        key.setBackground(round(primary ? GREEN : SURFACE, 12, primary ? GREEN : BORDER));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
        lp.leftMargin = dp(3);
        lp.rightMargin = dp(3);
        r.addView(key, lp);
        key.setOnClickListener(v -> action.run());
        key.setContentDescription(label.equals("⌫") ? "删除末位数字" : label);
    }

    private void inputKey(String key) {
        if (key.equals("⌫")) {
            if (!editBuffer.isEmpty()) editBuffer = editBuffer.substring(0, editBuffer.length() - 1);
            replaceFirstDigit = false;
        } else if (key.equals(".")) {
            if (replaceFirstDigit) editBuffer = "0.";
            else if (!editBuffer.contains(".")) editBuffer = editBuffer.isEmpty() ? "0." : editBuffer + ".";
            replaceFirstDigit = false;
        } else {
            if (replaceFirstDigit) editBuffer = key;
            else if (editBuffer.equals("0")) editBuffer = key;
            else if (editBuffer.length() < 15) editBuffer += key;
            replaceFirstDigit = false;
        }
        updateKeypad();
    }

    private void updateKeypad() {
        if (keypadValue != null) keypadValue.setText(editBuffer.isEmpty() ? "0" : editBuffer);
    }

    private void commitEditing() {
        if (editing < 0) return;
        values[editing] = editBuffer;
        if (editing == 3 || editing == 5) mode = MANUAL;
        save();
        showHome();
    }

    @Override public void onBackPressed() {
        if (editing >= 0) commitEditing();
        else super.onBackPressed();
    }

    private Summary compute() {
        Summary s = new Summary();
        double m = number(0), a = number(1), b = number(2), c = number(4);
        if (!Double.isFinite(m) || m <= 0 || !Double.isFinite(a) || a <= 1
                || !Double.isFinite(b) || b <= 1
                || (slips == 3 && (!Double.isFinite(c) || c <= 1))) {
            s.status = "请输入金额及有效赔率（赔率 > 1）";
            s.statusColor = WARN;
            return s;
        }
        try {
            if (slips == 3) computeThree(s, m, a, b, c);
            else computeTwo(s, m, a, b);
        } catch (IllegalArgumentException e) {
            s.status = e.getMessage();
            s.statusColor = BAD;
        }
        return s;
    }

    private void computeTwo(Summary s, double m, double a, double b) {
        HedgeMath.Result suggested = HedgeMath.calculate(m, a, b, 0);
        double desired = mode == BALANCED ? suggested.balancedHedge : suggested.minHedge;
        if (mode != MANUAL) values[3] = decimal(desired);
        s.proposed = (mode == BALANCED ? "均衡建议：" : "保本建议：") + cash(desired);
        double stake = number(3);
        s.minimum = suggested.bothCanBreakEven
                ? "保本区间：" + cash(suggested.minHedge) + " ～ " + cash(suggested.maxHedge)
                : "保本区间：无";
        s.equal = "均衡金额：" + cash(suggested.balancedHedge);
        if (!Double.isFinite(stake) || stake < 0) {
            s.status = "请输入非负保险金额";
            s.statusColor = BAD;
            return;
        }
        HedgeMath.Result r = HedgeMath.calculate(m, a, b, stake);
        boolean noLoss = r.mainProfit >= -0.005 && r.hedgeProfit >= -0.005;
        s.status = noLoss ? "✓ 两种比分任一命中均不亏"
                : suggested.bothCanBreakEven ? "⚠ 当前金额不在双向保本区间" : "⚠ 当前赔率无法双向保本";
        s.statusColor = noLoss ? GREEN : BAD;
        s.mainProfit = r.mainProfit;
        s.cover1Profit = r.hedgeProfit;
        s.otherProfit = -r.totalAtRisk;
    }

    private void computeThree(Summary s, double m, double a, double b, double c) {
        HedgeMath.ThreeResult suggested = HedgeMath.calculateThree(m, a, b, c, 0, 0);
        boolean possible = suggested.hedgesCanBothBreakEven;
        if (mode == BALANCED) {
            values[3] = decimal(suggested.balancedCover1);
            values[5] = decimal(suggested.balancedCover2);
        } else if (mode == BREAK_EVEN && possible) {
            values[3] = decimal(suggested.minCover1);
            values[5] = decimal(suggested.minCover2);
        }
        s.proposed = mode == BALANCED
                ? "三单均衡：①" + cash(suggested.balancedCover1) + " ②" + cash(suggested.balancedCover2)
                : possible ? "双保险保本：①" + cash(suggested.minCover1) + " ②" + cash(suggested.minCover2)
                : "⚠ 当前赔率无法双保险保本";
        s.minimum = possible
                ? "保本配对：①" + cash(suggested.minCover1) + " ②" + cash(suggested.minCover2)
                : "保本配对：无";
        s.equal = "均衡配对：①" + cash(suggested.balancedCover1) + " ②" + cash(suggested.balancedCover2);
        double x = number(3), y = number(5);
        if (!Double.isFinite(x) || x < 0 || !Double.isFinite(y) || y < 0) {
            s.status = possible ? "请输入两张保险金额" : "赔率条件不足，无法双保险保本";
            s.statusColor = BAD;
            s.coverage = "三张总本金：—\n保险1赔付：—\n保险2赔付：—";
            return;
        }
        HedgeMath.ThreeResult r = HedgeMath.calculateThree(m, a, b, c, x, y);
        boolean oneCovered = r.cover1Profit >= -0.005;
        boolean twoCovered = r.cover2Profit >= -0.005;
        boolean mainCovered = r.mainProfit >= -0.005;
        s.coverage = "总本金：" + cash(r.totalAtRisk)
                + "\n保险1赔付：" + cash(x * b) + (oneCovered ? " ✓覆盖" : " ×不足")
                + "\n保险2赔付：" + cash(y * c) + (twoCovered ? " ✓覆盖" : " ×不足");
        s.coverageColor = oneCovered && twoCovered ? GREEN : BAD;
        if (oneCovered && twoCovered) {
            s.status = mainCovered ? "✓ 三种比分任一命中均不亏"
                    : "✓ 双保险保本；⚠ 主单命中仍亏损";
            s.statusColor = mainCovered ? GREEN : WARN;
        } else {
            s.status = !possible ? "⚠ 当前赔率无法双保险同时保本"
                    : "⚠ 当前金额至少一张保险仍亏损";
            s.statusColor = BAD;
        }
        s.mainProfit = r.mainProfit;
        s.cover1Profit = r.cover1Profit;
        s.cover2Profit = r.cover2Profit;
        s.otherProfit = -r.totalAtRisk;
    }

    private double number(int index) {
        String value = values[index];
        if (value == null || value.trim().isEmpty()) return Double.NaN;
        try {
            // The custom keypad uses '.' only; a legitimate 5.500 is 5.5, not 5500.
            if (value.contains(",")) return HedgeMath.parse(value);
            return Double.parseDouble(value.trim());
        } catch (NumberFormatException ex) {
            return Double.NaN;
        }
    }

    private void save() {
        SharedPreferences.Editor e = prefs.edit();
        for (int i = 0; i < PREF.length; i++) e.putString(PREF[i], values[i]);
        e.putInt("mode", mode).apply();
    }

    private String cash(double v) { return Double.isFinite(v) ? money.format(v) : "—"; }
    private static String decimal(double d) { return String.format(Locale.US, "%.2f", d); }
    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }

    private static LinearLayout column(Activity context) {
        LinearLayout l = new LinearLayout(context);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout column() { return column(this); }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }
    private TextView text(String value, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(color);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setIncludeFontPadding(false);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private GradientDrawable round(int bg, int radius, int border) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(bg);
        shape.setCornerRadius(dp(radius));
        shape.setStroke(dp(1), border);
        return shape;
    }
    private LinearLayout.LayoutParams lineParams(int hDp, int mtDp, int mbDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(hDp));
        lp.topMargin = dp(mtDp);
        lp.bottomMargin = dp(mbDp);
        return lp;
    }

    private static final class Summary {
        String proposed = "建议金额：—";
        String status = "";
        int statusColor = BAD;
        String coverage = "";
        int coverageColor = DIM;
        String minimum = "保本配对：—";
        String equal = "均衡金额：—";
        double mainProfit = Double.NaN;
        double cover1Profit = Double.NaN;
        double cover2Profit = Double.NaN;
        double otherProfit = Double.NaN;
    }
}
