package com.hthedge.watch8;

import java.util.Locale;
import java.math.BigDecimal;
import java.math.RoundingMode;

/** Pure arithmetic: independent of Android UI, easy to test. */
public final class HedgeMath {
    private HedgeMath() {}

    public static final class Result {
        public final double minHedge;
        public final double maxHedge;
        public final double balancedHedge;
        public final double mainProfit;
        public final double hedgeProfit;
        public final double totalAtRisk;
        public final boolean bothCanBreakEven;
        Result(double min, double max, double equal, double p1, double p2, double risk, boolean feasible) {
            minHedge = min; maxHedge = max; balancedHedge = equal;
            mainProfit = p1; hedgeProfit = p2; totalAtRisk = risk;
            bothCanBreakEven = feasible;
        }
    }

    public static Result calculate(double main, double mainOdds, double coverOdds, double cover) {
        validate(main, mainOdds);
        validateOdds(coverOdds);
        validateStake(cover);
        double rawMin = main / (coverOdds - 1d);
        double rawMax = main * (mainOdds - 1d);
        double rawEqual = main * mainOdds / coverOdds;
        ensureFinite(rawMin, rawMax, rawEqual);
        double min = ceilCent(rawMin);
        double max = floorCent(rawMax);
        double balanced = roundCent(rawEqual);
        double mainProfit = main * mainOdds - main - cover;
        double hedgeProfit = cover * coverOdds - main - cover;
        double risk = main + cover;
        boolean feasible = min <= max + 1e-7;
        return new Result(min, max, balanced, mainProfit, hedgeProfit, risk, feasible);
    }

    /**
     * Three exclusive scores: main, hedge1 and hedge2. Exactly ONE score can win.
     * P(i) = winning_stake * decimal_odds - (main + hedge1 + hedge2).
     * All other scores lose all three stakes.
     */
    public static final class ThreeResult {
        public final double minCover1, minCover2;
        public final double balancedCover1, balancedCover2;
        public final double mainProfit, cover1Profit, cover2Profit, totalAtRisk;
        public final boolean hedgesCanBothBreakEven, allCanBreakEven;
        ThreeResult(double min1, double min2, double eq1, double eq2,
                double p0, double p1, double p2, double risk, boolean coverFeasible, boolean fullFeasible) {
            minCover1 = min1; minCover2 = min2;
            balancedCover1 = eq1; balancedCover2 = eq2;
            mainProfit = p0; cover1Profit = p1; cover2Profit = p2;
            totalAtRisk = risk;
            hedgesCanBothBreakEven = coverFeasible;
            allCanBreakEven = fullFeasible;
        }
    }

    public static ThreeResult calculateThree(double main, double mainOdds,
            double cover1Odds, double cover2Odds, double cover1, double cover2) {
        validate(main, mainOdds);
        validateOdds(cover1Odds);
        validateOdds(cover2Odds);
        validateStake(cover1);
        validateStake(cover2);

        double eq1 = roundCent(main * mainOdds / cover1Odds);
        double eq2 = roundCent(main * mainOdds / cover2Odds);
        ensureFinite(eq1, eq2);

        // Both insurance payouts must EACH cover the total cost (main + cover1 + cover2).
        // insurance1 * odds1 >= total, AND insurance2 * odds2 >= total.
        // Solve BOTH simultaneously rather than treating either insurance in isolation.
        // Exact decimal cent-rounding avoids recommendations a cent short of break-even.
        BigDecimal p = BigDecimal.valueOf(cover1Odds);
        BigDecimal q = BigDecimal.valueOf(cover2Odds);
        BigDecimal m = BigDecimal.valueOf(main);
        BigDecimal d = p.multiply(q).subtract(p).subtract(q);
        boolean possibleCovers = d.signum() > 0;
        double min1 = Double.NaN, min2 = Double.NaN;
        if (possibleCovers) {
            BigDecimal c1 = m.multiply(q).divide(d, 2, RoundingMode.CEILING);
            BigDecimal c2 = m.multiply(p).divide(d, 2, RoundingMode.CEILING);
            // A cent added to one insurance increases the required payout of the other.
            // Iterate upward until BOTH independently pay at least the new TOTAL cost.
            boolean verified = false;
            for (int k = 0; k < 2048; k++) {
                BigDecimal total = m.add(c1).add(c2);
                if (c1.multiply(p).compareTo(total) >= 0
                        && c2.multiply(q).compareTo(total) >= 0) {
                    verified = true;
                    break;
                }
                BigDecimal next1 = m.add(c2).divide(p.subtract(BigDecimal.ONE),
                        2, RoundingMode.CEILING);
                if (next1.compareTo(c1) > 0) c1 = next1;
                BigDecimal next2 = m.add(c1).divide(q.subtract(BigDecimal.ONE),
                        2, RoundingMode.CEILING);
                if (next2.compareTo(c2) > 0) c2 = next2;
            }
            if (!verified) {
                throw new IllegalArgumentException("赔率太接近双保险保本临界值，无法安全计算");
            }
            min1 = c1.doubleValue();
            min2 = c2.doubleValue();
            ensureFinite(min1, min2);
            if (min1 > 1e14 || min2 > 1e14) {
                throw new IllegalArgumentException("保险金额超出安全计算范围");
            }
        }

        double risk = main + cover1 + cover2;
        double p0 = main * mainOdds - risk;
        double p1 = cover1 * cover1Odds - risk;
        double p2 = cover2 * cover2Odds - risk;
        ensureFinite(risk);
        ensureFiniteSigned(p0, p1, p2);
        // Criterion for any set of stakes to give nonnegative returns on all 3 outcomes.
        boolean fullFeasible = (1d / mainOdds + 1d / cover1Odds + 1d / cover2Odds) <= 1d + 1e-10;
        return new ThreeResult(min1, min2, eq1, eq2, p0, p1, p2,
                risk, possibleCovers, fullFeasible);
    }

    private static void validate(double stake, double odds) {
        if (!Double.isFinite(stake) || stake <= 0) {
            throw new IllegalArgumentException("主单金额必须大于0");
        }
        validateOdds(odds);
    }
    private static void validateOdds(double odds) {
        if (!Double.isFinite(odds) || odds <= 1) {
            throw new IllegalArgumentException("赔率必须大于1");
        }
    }
    private static void validateStake(double stake) {
        if (!Double.isFinite(stake) || stake < 0) {
            throw new IllegalArgumentException("保险金额不能为负");
        }
    }
    private static void ensureFinite(double... values) {
        for (double v : values) if (!Double.isFinite(v) || v < 0)
            throw new IllegalArgumentException("输入数值过大");
    }
    private static void ensureFiniteSigned(double... values) {
        for (double v : values) if (!Double.isFinite(v))
            throw new IllegalArgumentException("输入数值过大");
    }
    private static double ceilCent(double x) { return Math.ceil(x * 100d - 1e-7) / 100d; }
    private static double floorCent(double x) { return Math.floor(x * 100d + 1e-7) / 100d; }
    private static double roundCent(double x) { return Math.round(x * 100d) / 100d; }

    /** Accept 10000, 10,000.00, 10.000,00, 5.50 and 5,50. */
    public static double parse(String input) {
        if (input == null) return Double.NaN;
        String s = input.trim().replace("$", "").replace(" ", "").replace("\u00a0", "");
        if (s.length() == 0) return Double.NaN;
        int dot = s.lastIndexOf('.');
        int comma = s.lastIndexOf(',');
        if (dot >= 0 && comma >= 0) {
            char decimal = (dot > comma) ? '.' : ',';
            char group = decimal == '.' ? ',' : '.';
            s = s.replace(String.valueOf(group), "");
            if (decimal == ',') s = s.replace(',', '.');
        } else if (dot >= 0 || comma >= 0) {
            char sep = dot >= 0 ? '.' : ',';
            int count = 0;
            for (int i = 0; i < s.length(); i++) if (s.charAt(i) == sep) count++;
            if (count > 1) s = s.replace(String.valueOf(sep), "");
            else {
                int index = s.indexOf(sep);
                int tail = s.length() - index - 1;
                if (tail == 3 && index <= 3 && index >= 1) s = s.replace(String.valueOf(sep), "");
                else s = s.replace(',', '.');
            }
        }
        try { return Double.parseDouble(s); } catch (NumberFormatException ex) { return Double.NaN; }
    }
}
