import com.hthedge.watch8.HedgeMath;

public class HedgeMathSmokeTest {
    private static void close(double a, double b, String label) {
        if (Math.abs(a - b) > 0.011) throw new AssertionError(label + ": " + a + " != " + b);
    }
    public static void main(String[] args) {
        // v3.3 two-slip: 100 @ 3.00, other odds 2.00, suggested 100.00,
        // both outcomes return 300.00 and 200.00 total stake respectively.
        HedgeMath.Result two = HedgeMath.calculate(100, 3, 2, 100);
        close(two.minHedge, 100, "two min");
        close(two.maxHedge, 200, "two max");
        close(two.balancedHedge, 150, "two balanced");
        close(two.mainProfit, 100, "two main profit");
        close(two.hedgeProfit, 0, "two hedge profit");
        close(two.totalAtRisk, 200, "two risk");
        if (!two.bothCanBreakEven) throw new AssertionError("two feasibility");

        // 3 exclusive outcomes: main stake=100, odds main/cover1/cover2=5.00,
        // 3.00, 3.00: each cover min=100; covers break even and main gains 200.
        HedgeMath.ThreeResult three = HedgeMath.calculateThree(100, 5, 3, 3, 100, 100);
        close(three.minCover1, 100, "three cover1 min");
        close(three.minCover2, 100, "three cover2 min");
        close(three.mainProfit, 200, "three main profit");
        close(three.cover1Profit, 0, "three cover1 profit");
        close(three.cover2Profit, 0, "three cover2 profit");
        close(three.totalAtRisk, 300, "three risk");
        if (!three.hedgesCanBothBreakEven || !three.allCanBreakEven)
            throw new AssertionError("three feasibility");

        HedgeMath.ThreeResult impossible = HedgeMath.calculateThree(100, 3, 2, 2, 0, 0);
        if (impossible.hedgesCanBothBreakEven) throw new AssertionError("impossible hedge");
        if (!Double.isNaN(impossible.minCover1)) throw new AssertionError("impossible min");
        System.out.println("All HedgeMath v3.3 regression checks passed.");
    }
}
